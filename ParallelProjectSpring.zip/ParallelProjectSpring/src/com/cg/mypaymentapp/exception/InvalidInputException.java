package com.cg.mypaymentapp.exception;

public class InvalidInputException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -9096123242335620546L;
	
	public InvalidInputException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
