package com.cg.mypaymentapp.exception;

public class WalletException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -663750680330306700L;

	public WalletException(String message) {
		// TODO Auto-generated constructor stub
		System.out.println(message);
	}
}
