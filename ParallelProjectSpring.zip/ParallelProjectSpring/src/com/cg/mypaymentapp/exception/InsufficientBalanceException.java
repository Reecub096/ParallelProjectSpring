package com.cg.mypaymentapp.exception;

public class InsufficientBalanceException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7705609436235818154L;
	
	public InsufficientBalanceException(String message) {
		// TODO Auto-generated constructor stub
		System.out.println(message);
	}

}
