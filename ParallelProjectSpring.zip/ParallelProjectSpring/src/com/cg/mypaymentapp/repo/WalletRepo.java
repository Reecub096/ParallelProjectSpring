package com.cg.mypaymentapp.repo;

import java.util.List;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Transact;
import com.cg.mypaymentapp.exception.WalletException;

public interface WalletRepo {
		
		public Customer showBalance (String mobileno);
		
		public void updateBalance(String mobNo, Double amount);
		
		public Customer createAccount(Customer customer);
		
		public Customer findOne(String mobNo);
		
		public boolean validateAccount(String mobNo) throws WalletException;
		
		public List<Transact> getAll(String mob);
		
		public boolean allTransactions(Transact t);

		

}
