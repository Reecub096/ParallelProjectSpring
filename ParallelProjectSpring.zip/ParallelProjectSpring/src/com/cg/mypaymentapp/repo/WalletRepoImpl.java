package com.cg.mypaymentapp.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Transact;
import com.cg.mypaymentapp.exception.WalletException;

@Repository("walletdao")
public class WalletRepoImpl implements WalletRepo{
	
		//Map<String, Customer> customerMap;
		@PersistenceContext
		EntityManager manager;
	
		public WalletRepoImpl() {
				// TODO Auto-generated constructor stub
				//customerMap = DataStore.createCollection();
				EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
				manager = emf.createEntityManager();
			
		}
	
		@Override
		public Customer showBalance(String mobileno) {       // Function to Show Balance of customer
				// TODO Auto-generated method stub
				manager.getTransaction().begin();
				 Customer customer = manager.find(Customer.class, mobileno);
				manager.getTransaction().commit();
				return customer;
		}
	
		@Override
		public void updateBalance(String mobNo, Double amount) {            // Function to update the balance of customer in DataBase
				// TODO Auto-generated method stub
				manager.getTransaction().begin();
				Query sourceQuery = manager.createQuery("UPDATE Customer SET amount = :sourcebal where mobile = :sourcemobile");
				sourceQuery.setParameter("sourcebal", amount);
				sourceQuery.setParameter("sourcemobile", mobNo);
				manager.getTransaction().commit();
		
		}
	
		@Override
		public Customer createAccount(Customer customer) {               //Function to create account of customers  in DataBase
				// TODO Auto-generated method stub
				manager.getTransaction().begin();
				manager.persist(customer);
				manager.getTransaction().commit();
				return customer;
		}
	
		@Override
		public Customer findOne(String mobNo) {							//Function to retrieve details of customers
				// TODO Auto-generated method stub	
			manager.getTransaction().begin();
			 Customer customer = manager.find(Customer.class, mobNo);
			manager.getTransaction().commit();
				return customer;
		}

		@Override
		public boolean validateAccount(String mobNo) throws WalletException {    			//Function to validate Account Details of customers
			
			manager.getTransaction().begin();
			Customer customer = manager.find(Customer.class, mobNo);
			manager.getTransaction().commit();
			if(customer == null)
				return false;
				return true;
		}

		@Override
		public List<Transact> getAll(String mob){									//receives trasactions from database
			//List<Transact> list= new ArrayList<Transact>();				//creating list to store all transactions
			TypedQuery<Transact> sql=manager.createQuery("select p from Transact p where mobile=:imob",Transact.class); 
			sql.setParameter("imob", mob);
			List <Transact> list=sql.getResultList();
			/*for (Transact transact : list) {
				System.out.println(transact);
			}*/
			
			return list;
		}

		@Override
		public boolean allTransactions(Transact t) {						//sends transactions to database		
			
			manager.persist(t);
			manager.flush();
			return true;
		}

		
}
